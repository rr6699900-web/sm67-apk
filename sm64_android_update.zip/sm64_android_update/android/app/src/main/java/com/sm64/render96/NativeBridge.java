package com.sm64.render96;
public final class NativeBridge {
    static { try { System.loadLibrary("main"); } catch (UnsatisfiedLinkError ignored) {} }
    public static native void setTouchState(int buttons, int sx, int sy, int cx, int cy);
}
