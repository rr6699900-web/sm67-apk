package com.sm64.render96;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import java.io.*;
import java.util.zip.*;

/** Backs up / restores the game's save folder to any cloud provider the user picks (Drive, OneDrive, Dropbox...). */
public final class CloudSync {
    public static final int REQ_EXPORT = 7101, REQ_IMPORT = 7102;
    private final Activity act; private final File saveDir;
    public CloudSync(Activity a, File saveDir) { act = a; this.saveDir = saveDir; }

    public void startExport() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/zip").putExtra(Intent.EXTRA_TITLE, "sm64_saves_backup.zip");
        act.startActivityForResult(i, REQ_EXPORT);
    }
    public void startImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/zip");
        act.startActivityForResult(i, REQ_IMPORT);
    }
    /** Call from Activity.onActivityResult. Returns a user-facing message, or null if not ours. */
    public String handleResult(int req, int res, Intent data) {
        if (res != Activity.RESULT_OK || data == null || data.getData() == null) return null;
        try {
            if (req == REQ_EXPORT) { zipTo(data.getData()); return "Saves backed up to the cloud location you chose."; }
            if (req == REQ_IMPORT) { unzipFrom(data.getData()); return "Saves restored. Restart the game to load them."; }
        } catch (IOException e) { return "Sync failed: " + e.getMessage(); }
        return null;
    }
    private void zipTo(Uri uri) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(act.getContentResolver().openOutputStream(uri))) {
            File[] fs = saveDir.listFiles(); if (fs == null) return;
            for (File f : fs) if (f.isFile()) { z.putNextEntry(new ZipEntry(f.getName()));
                try (InputStream in = new FileInputStream(f)) { copy(in, z); } z.closeEntry(); }
        }
    }
    private void unzipFrom(Uri uri) throws IOException {
        saveDir.mkdirs();
        try (ZipInputStream z = new ZipInputStream(act.getContentResolver().openInputStream(uri))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String name = new File(e.getName()).getName();        // blocks path traversal
                if (name.isEmpty() || e.isDirectory()) continue;
                File tmp = new File(saveDir, name + ".tmp");
                try (OutputStream out = new FileOutputStream(tmp)) { copy(z, out); }
                File dst = new File(saveDir, name); if (dst.exists()) dst.renameTo(new File(saveDir, name + ".bak"));
                tmp.renameTo(dst);
            }
        }
    }
    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }
}
