package com.sm64.render96;

import android.content.Context;
import android.graphics.*;
import android.os.Build;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

/** Transparent overlay: analog stick (left), A/B/Z/Start + C-buttons (right). Full multitouch. */
public class TouchControlsView extends View {
    // N64 button masks (ultra64 OSContPad)
    static final int A = 0x8000, B = 0x4000, Z = 0x2000, START = 0x1000,
                     CU = 0x0008, CD = 0x0004, CL = 0x0002, CR = 0x0001, L = 0x0020, R = 0x0010;

    private static class Btn {
        final String label; final int mask; final float cx, cy, r; // cx,cy,r as fractions of height/width
        int pointer = -1; Btn(String l, int m, float x, float y, float r) { label = l; mask = m; cx = x; cy = y; this.r = r; }
    }
    private final Btn[] btns = {
        new Btn("A", A, 0.90f, 0.72f, 0.11f), new Btn("B", B, 0.78f, 0.84f, 0.09f),
        new Btn("Z", Z, 0.10f, 0.30f, 0.07f), new Btn("R", R, 0.90f, 0.30f, 0.07f),
        new Btn("▲", CU, 0.70f, 0.52f, 0.05f), new Btn("▼", CD, 0.70f, 0.68f, 0.05f),
        new Btn("◀", CL, 0.64f, 0.60f, 0.05f), new Btn("▶", CR, 0.76f, 0.60f, 0.05f),
        new Btn("START", START, 0.50f, 0.92f, 0.05f),
    };
    private int stickPointer = -1;
    private float stickCx, stickCy, thumbX, thumbY, baseR;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG),
                        text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float opacity = 0.55f, scale = 1f;

    public TouchControlsView(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE); ring.setStrokeWidth(4f); ring.setColor(Color.WHITE);
        text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.CENTER); text.setFakeBoldText(true);
    }
    public void setOpacity(float o) { opacity = Math.max(0.15f, Math.min(1f, o)); invalidate(); }
    public void setScale(float s) { scale = Math.max(0.6f, Math.min(1.6f, s)); invalidate(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        baseR = h * 0.17f * scale; stickCx = w * 0.14f; stickCy = h * 0.74f; thumbX = stickCx; thumbY = stickCy;
    }
    private float bx(Btn b) { return b.cx * getWidth(); }
    private float by(Btn b) { return b.cy * getHeight(); }
    private float br(Btn b) { return b.r * getHeight() * 1.6f * scale; }

    @Override protected void onDraw(Canvas c) {
        int a = (int) (opacity * 255);
        // stick
        fill.setColor(Color.argb(a / 2, 20, 20, 40)); c.drawCircle(stickCx, stickCy, baseR, fill);
        ring.setAlpha(a); c.drawCircle(stickCx, stickCy, baseR, ring);
        fill.setShader(new RadialGradient(thumbX, thumbY - baseR * .2f, baseR * .6f,
                Color.argb(a, 255, 255, 255), Color.argb(a, 120, 150, 255), Shader.TileMode.CLAMP));
        c.drawCircle(thumbX, thumbY, baseR * 0.45f, fill); fill.setShader(null);
        // buttons
        for (Btn b : btns) {
            boolean down = b.pointer != -1;
            int col = b.mask == A ? Color.rgb(60, 190, 90) : b.mask == B ? Color.rgb(230, 70, 70)
                    : (b.mask & (CU | CD | CL | CR)) != 0 ? Color.rgb(250, 200, 40) : Color.rgb(110, 120, 150);
            fill.setColor(Color.argb(down ? Math.min(255, a + 70) : a, Color.red(col), Color.green(col), Color.blue(col)));
            float r = br(b) * (down ? 0.92f : 1f);
            c.drawCircle(bx(b), by(b), r, fill); ring.setAlpha(a); c.drawCircle(bx(b), by(b), r, ring);
            text.setTextSize(r * (b.label.length() > 2 ? 0.55f : 0.9f)); text.setAlpha(Math.min(255, a + 80));
            c.drawText(b.label, bx(b), by(b) + text.getTextSize() * 0.35f, text);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked(), idx = e.getActionIndex();
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            float x = e.getX(idx), y = e.getY(idx); int id = e.getPointerId(idx);
            boolean hit = false;
            for (Btn b : btns) if (Math.hypot(x - bx(b), y - by(b)) <= br(b) * 1.25f) {
                b.pointer = id; hit = true; performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); break; }
            if (!hit && x < getWidth() * 0.45f && stickPointer == -1) { // floating stick: base appears where you touch
                stickPointer = id; stickCx = x; stickCy = y; thumbX = x; thumbY = y;
            }
        } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_POINTER_UP || act == MotionEvent.ACTION_CANCEL) {
            int id = e.getPointerId(idx);
            for (Btn b : btns) if (b.pointer == id) b.pointer = -1;
            if (stickPointer == id || act == MotionEvent.ACTION_CANCEL) { stickPointer = -1; thumbX = stickCx; thumbY = stickCy; }
        }
        if (stickPointer != -1) {
            int i = e.findPointerIndex(stickPointer);
            if (i >= 0) {
                float dx = e.getX(i) - stickCx, dy = e.getY(i) - stickCy, d = (float) Math.hypot(dx, dy);
                if (d > baseR) { dx *= baseR / d; dy *= baseR / d; }
                thumbX = stickCx + dx; thumbY = stickCy + dy;
            }
        }
        push(); invalidate(); return true;
    }

    private void push() {
        int mask = 0; for (Btn b : btns) if (b.pointer != -1) mask |= b.mask;
        float nx = (thumbX - stickCx) / baseR, ny = -(thumbY - stickCy) / baseR;
        float mag = (float) Math.hypot(nx, ny);
        if (mag < 0.12f) { nx = 0; ny = 0; }                          // dead zone
        else { float s = Math.min(1f, (mag - 0.12f) / 0.88f) / mag; nx *= s; ny *= s; }
        NativeBridge.setTouchState(mask, Math.round(nx * 80), Math.round(ny * 80), 0, 0); // N64 stick range ≈ ±80
    }
}
