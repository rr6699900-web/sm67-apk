# SM64 Render96 Android — touch controls + cloud saves

## Done (written, NOT compiled or device-tested)
- `patches/src/pc/controller/controller_touch.{c,h}` — new controller backend, merged into the pad each frame (multitouch-safe, atomic).
- `controller_touch_jni.c` — JNI entry `NativeBridge.setTouchState`.
- `patches/apply_touch_patch.sh` — registers the backend in `controller_entry_point.c`.
- `TouchControlsView.java` — floating analog stick (dead zone, N64 ±80 range), A/B/Z/R/Start, C-buttons, haptics, adjustable opacity/size.
- `CloudSync.java` — back up/restore saves to Drive/OneDrive/Dropbox via Android's file picker (no API keys).
- `.github/workflows/build-apk.yml` — builds the APK in the cloud.

## Not done (needs a machine with Android SDK + NDK)
1. `android/` still needs the Gradle project from your template (AGP 4.0.1 is too old; use AGP 8.x, minSdk 24+) and an Activity that hosts SDL2 + `TouchControlsView`.
2. Render96ex has no Android build. It needs an NDK build of SDL2 + GLES2 renderer (`gfx_opengl.c` → GLES), asset extraction from your ROM, and loading `libmain.so`. This is the largest remaining task.
3. Mapping the 64x64 pack to real texture names, and HD "enhanced graphics", are separate work.
4. Settings screen / text polish: not started.
