#ifdef __ANDROID__
#include <jni.h>
#include "controller_touch.h"
JNIEXPORT void JNICALL
Java_com_sm64_render96_NativeBridge_setTouchState(JNIEnv *e, jclass c,
        jint buttons, jint sx, jint sy, jint cx, jint cy) {
    touch_set_state(buttons, sx, sy, cx, cy);
}
#endif
