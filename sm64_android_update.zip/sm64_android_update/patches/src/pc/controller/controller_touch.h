#ifndef CONTROLLER_TOUCH_H
#define CONTROLLER_TOUCH_H
#include "controller_api.h"
extern struct ControllerAPI controller_touch;
// Called from the JNI bridge (Android UI thread). Thread-safe via atomics.
void touch_set_state(int buttons, int stick_x, int stick_y, int cam_x, int cam_y);
#endif
