#include <stdatomic.h>
#include <ultra64.h>
#include "controller_api.h"
#include "controller_touch.h"

static _Atomic int t_buttons, t_sx, t_sy, t_cx, t_cy;

void touch_set_state(int buttons, int sx, int sy, int cx, int cy) {
    atomic_store(&t_buttons, buttons);
    atomic_store(&t_sx, sx); atomic_store(&t_sy, sy);
    atomic_store(&t_cx, cx); atomic_store(&t_cy, cy);
}

static void touch_init(void) {}

static void touch_read(OSContPad *pad) {
    pad->button |= (u16) atomic_load(&t_buttons);
    int sx = atomic_load(&t_sx), sy = atomic_load(&t_sy);
    int cx = atomic_load(&t_cx), cy = atomic_load(&t_cy);
    if (sx || sy) { pad->stick_x = (s8) sx; pad->stick_y = (s8) sy; }
    if (cx || cy) { pad->ext_stick_x = (s8) cx; pad->ext_stick_y = (s8) cy; }
}

static u32 touch_rawkey(void) { return VK_INVALID; }

struct ControllerAPI controller_touch = {
    0x2000, touch_init, touch_read, touch_rawkey, NULL, NULL, NULL, NULL
};
