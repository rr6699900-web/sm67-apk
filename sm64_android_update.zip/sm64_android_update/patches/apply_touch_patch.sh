#!/bin/sh
# Run from the Render96ex-master directory. Registers the touch backend.
set -e
F=src/pc/controller/controller_entry_point.c
grep -q controller_touch.h $F || {
  sed -i 's|#include "controller_sdl.h"|#include "controller_sdl.h"\n#include "controller_touch.h"|' $F
  sed -i 's|    &controller_keyboard,|    \&controller_keyboard,\n#ifdef __ANDROID__\n    \&controller_touch,\n#endif|' $F
}
echo "touch backend registered in $F"
